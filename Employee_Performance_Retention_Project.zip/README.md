# Employee Performance and Retention Analysis

This is a complete minor-level Data Science / Machine Learning project.

## Project Files

- `main.py` : Complete Python source code
- `employee_data.csv` : Sample employee dataset
- `requirements.txt` : Required Python libraries

## How to Run

1. Open this folder in VS Code, PyCharm, or Jupyter.
2. Install libraries:

```bash
pip install -r requirements.txt
```

3. Run the project:

```bash
python main.py
```

## Project Modules

- Data loading and cleaning
- Exploratory Data Analysis
- Attrition probability analysis
- Feature encoding and scaling
- Attrition prediction using Logistic Regression
- Performance prediction using Linear Regression
- Deep Learning models using TensorFlow/Keras
- Final HR insights

## Dataset Columns

- EmployeeID
- Name
- Age
- Department
- Salary
- ExperienceYears
- TrainingHours
- SatisfactionScore
- WorkLifeBalance
- PerformanceScore
- Attrition

## Interview Explanation

This project predicts employee attrition and performance using HR-related factors like salary, performance score, department, experience, training hours, satisfaction score, and work-life balance. It helps HR teams identify employees who may leave the organization and understand which factors influence employee performance.
